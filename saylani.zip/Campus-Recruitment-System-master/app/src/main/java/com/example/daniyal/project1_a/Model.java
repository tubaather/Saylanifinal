package com.example.daniyal.project1_a;

/**
 * Created by Daniyal on 7/19/2017.
 */

public class Model {

    public String type;

    public Model(){}

    public Model(String type){

        this.type = type;
    }

}
